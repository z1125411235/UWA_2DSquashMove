# SimpleSquashAndStretchMovement2D
![Gif](https://i.imgur.com/CHPBZNv.gif)
